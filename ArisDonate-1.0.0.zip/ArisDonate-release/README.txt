═══════════════════════════════════════════════════════════════
   ArisDonate v1.0.0 — Minecraft 1.21.x (Paper) донат-плагин
═══════════════════════════════════════════════════════════════

УСТАНОВКА:
  1. Распакуйте этот ZIP.
  2. Скопируйте plugin/ArisDonate-1.0.0.jar в папку plugins/ вашего
     Paper-сервера 1.21.x.
  3. Запустите сервер — будет создан plugins/ArisDonate/config.yml.
  4. Отредактируйте config.yml и перезапустите сервер.

ТРЕБОВАНИЯ:
  - Paper 1.21.x (рекомендуется 1.21.4 build 230+)
  - Java 21

ОСНОВНЫЕ КОМАНДЫ:
  /donate (/don)             — GUI донат-магазина (шалкеры с описанием/командами/лимитом регионов)
  /arisdonate give|set|remove|list|reload <ник> <донат>
                              — админ-управление донатами
  /sethome /home /delhome /renamehome /homes
  /setwarp /warp /delwarp /warps
  /spawn /setspawn (admin)
  /tp /tpa /tphere /tpahere /tpaccept (с кликабельными ✔/✘) /tpadeny /tpall /tppos /back
  /msg /tell /w /pm /r /reply /me /broadcast /afk /socialspy
  /vanish (/v) /gm /gmc /gms /gma /gmsp /fly /speed
  /ban /tempban /unban /kick /mute /unmute /freeze /jail /unjail /setjail /warn
  /heal /feed /god /cure /effect /clearinv
  /inv /invsee /ec /enderchest
  /time /day /night /weather /sun /rain /thunder /worldtp
  /seen /near /playerlist /tps /ping /whois
  /top /jump /repair /craft /workbench /anvil /grindstone /loom /smithing /cartography
  /give /i /more /skull /hat /smite /burn /extinguish /lightning
  /clearchat /nick /unnick /realname /condense /sudo /commandspy
  /kit /kits /shop /rules /motd /help-aris /adreload

ДОНАТЫ (из коробки):
  • Spark   — 5 регионов,   зелёный градиент
  • Luna    — 15 регионов,  серебристо-фиолетовый
  • Stellar — 30 регионов,  голубой
  • Nova    — 50 регионов,  пурпурный
  • Aris    — 100 регионов, ЖЁЛТО-ОРАНЖЕВЫЙ ГРАДИЕНТ (самый мощный)
              кит: незеритка Prot V, меч Sharp VI + Fire Aspect III,
              Эфирные крылья, тотемы, эндер-перлы, мендинг, фаер-аспект

Префикс доната отображается ПЕРЕД ником в чате и в табе,
без квадратных скобок, с RGB-градиентом (через scoreboard team prefix).

Покраска: <grad:#FFD700:#FF8C00>текст</grad>, &#RRGGBB, и стандартные &-коды.

ВЫДАЧА ДОНАТА:
  /arisdonate give Steve aris
  /arisdonate remove Steve

ВЫДАЧА КИТА:
  /kit aris  (нужно право arisdonate.kit.aris)

ПРАВА:
  arisdonate.admin                 — полный доступ
  arisdonate.<команда>             — отдельные права (см. plugin.yml)
  arisdonate.kit.<id>              — право на конкретный кит

ИСХОДНЫЙ КОД:
  В папке source/ лежит полный Maven-проект.
  Сборка: cd source && mvn clean package
  Артефакт: source/target/ArisDonate-1.0.0.jar

═══════════════════════════════════════════════════════════════
