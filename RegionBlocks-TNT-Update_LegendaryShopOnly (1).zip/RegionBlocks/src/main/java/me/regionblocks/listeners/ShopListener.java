package me.regionblocks.listeners;

import me.regionblocks.RegionBlocks;
import me.regionblocks.managers.ArisItemManager;
import me.regionblocks.managers.LegendaryItemManager;
import me.regionblocks.managers.MinecartItemManager;
import me.regionblocks.managers.TntItemManager;
import me.regionblocks.models.MinecartType;
import me.regionblocks.models.RegionTier;
import me.regionblocks.models.TntType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class ShopListener implements Listener {

    private static final String TITLE_PRIVATES  = "✦ Магазин — Приваты ✦";
    private static final String TITLE_TNT       = "✦ Магазин — ТНТ ✦";
    private static final String TITLE_MINECART  = "✦ Магазин — Вагонетки ✦";

    private final RegionBlocks plugin;

    public ShopListener(RegionBlocks plugin) {
        this.plugin = plugin;
    }

    // ══ Открытие разделов ════════════════════════════════════════════════════

    public void openShop(Player player) { openPrivatesTab(player); }

    public void openPrivatesTab(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54,
            Component.text(TITLE_PRIVATES).color(TextColor.color(0xFFAA00)));
        fillBorder(inv);
        long bal = plugin.getArisManager().getBalance(player.getName());

        inv.setItem(10, shopItem(RegionTier.COMMON,    bal, 100));
        inv.setItem(12, shopItem(RegionTier.RARE,      bal, 300));
        inv.setItem(14, shopItem(RegionTier.EPIC,      bal, 700));
        inv.setItem(16, shopItem(RegionTier.MYTHIC,    bal, 1500));
        inv.setItem(29, shopItem(RegionTier.LEGENDARY, bal, 4000));
        inv.setItem(33, arisShopItem(bal, 10000));
        inv.setItem(31, balanceDisplay(bal));

        // Навигация: ТНТ слева (слот 45), вагонетки справа (слот 53)
        inv.setItem(46, tabButton(Material.TNT,           "§c💣 ТНТ",         "Открыть раздел ТНТ"));
        inv.setItem(52, tabButton(Material.TNT_MINECART,  "§6🚃 Вагонетки",   "Открыть раздел вагонеток"));

        player.openInventory(inv);
    }

    public void openTntTab(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54,
            Component.text(TITLE_TNT).color(TextColor.color(0xFF4422)));
        fillBorder(inv);
        long bal = plugin.getArisManager().getBalance(player.getName());

        int[] slots = {11, 13, 15, 20};
        TntType[] types = TntType.values();
        for (int i = 0; i < types.length && i < slots.length; i++)
            inv.setItem(slots[i], tntShopItem(types[i], bal));

        inv.setItem(29, rgbItem(Material.RED_DYE,   "§cКрасный порошок",  "Усиливает взрыв"));
        inv.setItem(31, rgbItem(Material.GREEN_DYE, "§aЗелёный порошок",  "Расширяет радиус"));
        inv.setItem(33, rgbItem(Material.BLUE_DYE,  "§9Синий порошок",    "Пробивает защиту"));
        inv.setItem(22, balanceDisplay(bal));

        inv.setItem(46, tabButton(Material.IRON_ORE,      "§6🏠 Приваты",    "Вернуться к приватам"));
        inv.setItem(52, tabButton(Material.TNT_MINECART,  "§6🚃 Вагонетки",  "Открыть раздел вагонеток"));

        player.openInventory(inv);
    }

    public void openMinecartTab(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54,
            Component.text(TITLE_MINECART).color(TextColor.color(0xFF8800)));
        fillBorder(inv);
        long bal = plugin.getArisManager().getBalance(player.getName());

        int[] slots = {11, 13, 15, 20};
        MinecartType[] types = MinecartType.values();
        for (int i = 0; i < types.length && i < slots.length; i++)
            inv.setItem(slots[i], minecartShopItem(types[i], bal));

        inv.setItem(22, balanceDisplay(bal));

        inv.setItem(46, tabButton(Material.IRON_ORE, "§6🏠 Приваты",  "Вернуться к приватам"));
        inv.setItem(52, tabButton(Material.TNT,      "§c💣 ТНТ",      "Открыть раздел ТНТ"));

        player.openInventory(inv);
    }

    // ══ Обработка кликов ═════════════════════════════════════════════════════

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;

        String plain = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
            .plainText().serialize(e.getView().title());

        boolean isPrivates = plain.contains("Приваты");
        boolean isTnt      = plain.contains("ТНТ");
        boolean isMinecart = plain.contains("Вагонетки");
        if (!isPrivates && !isTnt && !isMinecart) return;

        e.setCancelled(true);
        if (e.getCurrentItem() == null || e.getCurrentItem().getType() == Material.AIR) return;

        int slot = e.getSlot();

        if (isPrivates) {
            switch (slot) {
                case 10 -> buy(player, RegionTier.COMMON,    100);
                case 12 -> buy(player, RegionTier.RARE,      300);
                case 14 -> buy(player, RegionTier.EPIC,      700);
                case 16 -> buy(player, RegionTier.MYTHIC,    1500);
                case 29 -> buy(player, RegionTier.LEGENDARY, 4000);
                case 33 -> buyAris(player, 10000);
                case 46 -> openTntTab(player);
                case 52 -> openMinecartTab(player);
            }
        } else if (isTnt) {
            switch (slot) {
                case 11 -> buyTnt(player, TntType.BASIC);
                case 13 -> buyTnt(player, TntType.STRONG);
                case 15 -> buyTnt(player, TntType.MEGA);
                case 20 -> buyTnt(player, TntType.TITAN);
                case 46 -> openPrivatesTab(player);
                case 52 -> openMinecartTab(player);
            }
        } else { // Вагонетки
            switch (slot) {
                case 11 -> buyMinecart(player, MinecartType.BASIC);
                case 13 -> buyMinecart(player, MinecartType.STRONG);
                case 15 -> buyMinecart(player, MinecartType.MEGA);
                case 20 -> buyMinecart(player, MinecartType.TITAN);
                case 46 -> openPrivatesTab(player);
                case 52 -> openTntTab(player);
            }
        }
    }

    // ══ Покупки ══════════════════════════════════════════════════════════════

    private void buy(Player player, RegionTier tier, long price) {
        if (!plugin.getArisManager().take(player.getName(), price)) { noMoney(player, price); return; }
        ItemStack item = (tier == RegionTier.LEGENDARY)
            ? LegendaryItemManager.createLegendaryBlock()
            : new ItemStack(tier.getBlockMaterial(), 1);
        player.getInventory().addItem(item);
        player.closeInventory();
        bought(player, tier.getDisplayName(), price);
    }

    private void buyAris(Player player, long price) {
        if (!plugin.getArisManager().take(player.getName(), price)) { noMoney(player, price); return; }
        player.getInventory().addItem(ArisItemManager.createArisBlock());
        player.closeInventory();
        bought(player, "§6Арис", price);
    }

    private void buyTnt(Player player, TntType type) {
        if (!plugin.getArisManager().take(player.getName(), type.getPrice())) { noMoney(player, type.getPrice()); return; }
        player.getInventory().addItem(TntItemManager.createTnt(type));
        player.closeInventory();
        bought(player, type.getDisplayName(), type.getPrice());
    }

    private void buyMinecart(Player player, MinecartType type) {
        if (!plugin.getArisManager().take(player.getName(), type.getPrice())) { noMoney(player, type.getPrice()); return; }
        player.getInventory().addItem(MinecartItemManager.createMinecart(type));
        player.closeInventory();
        bought(player, type.getDisplayName(), type.getPrice());
    }

    private void noMoney(Player player, long price) {
        player.sendMessage(
            Component.text("✗ Недостаточно Арисов! Нужно: ").color(TextColor.color(0xFF4444))
            .append(Component.text(fmt(price) + " ✦").color(TextColor.color(0xFF8000))
                .decoration(TextDecoration.BOLD, true))
        );
        player.closeInventory();
    }

    private void bought(Player player, String name, long price) {
        long bal = plugin.getArisManager().getBalance(player.getName());
        player.sendMessage(Component.text(""));
        player.sendMessage(Component.text("  ✦ Куплено: ").color(TextColor.color(0x55FF55))
            .append(Component.text(name + "§r")));
        player.sendMessage(Component.text("  Списано: ").color(TextColor.color(0xAAAAAA))
            .append(Component.text(fmt(price) + " ✦").color(TextColor.color(0xFF8000))
                .decoration(TextDecoration.BOLD, true)));
        player.sendMessage(Component.text("  Остаток: ").color(TextColor.color(0xAAAAAA))
            .append(Component.text(fmt(bal) + " ✦").color(TextColor.color(0xFFAA33))));
        player.sendMessage(Component.text(""));
    }

    // ══ Предметы-иконки ══════════════════════════════════════════════════════

    private ItemStack shopItem(RegionTier tier, long bal, long price) {
        ItemStack item = new ItemStack(tier.getBlockMaterial());
        ItemMeta meta = item.getItemMeta();
        boolean can = bal >= price;
        int s = tier.getSize();
        meta.displayName(Component.text(tier.getDisplayName() + " §r приват")
            .color(TextColor.color(tier.getColor()))
            .decoration(TextDecoration.ITALIC, false).decoration(TextDecoration.BOLD, true));
        meta.lore(List.of(
            Component.text(""),
            Component.text("  Размер: ").color(TextColor.color(0x888888)).decoration(TextDecoration.ITALIC, false)
                .append(Component.text(s + "×" + s + "×" + s).color(TextColor.color(0xFFCC55)).decoration(TextDecoration.ITALIC, false)),
            Component.text(""),
            Component.text("  Цена: ").color(TextColor.color(0x888888)).decoration(TextDecoration.ITALIC, false)
                .append(Component.text(fmt(price) + " ✦").color(TextColor.color(0xFF8000))
                    .decoration(TextDecoration.BOLD, true).decoration(TextDecoration.ITALIC, false)),
            Component.text("  Баланс: ").color(TextColor.color(0x888888)).decoration(TextDecoration.ITALIC, false)
                .append(Component.text(fmt(bal) + " ✦")
                    .color(can ? TextColor.color(0x55FF55) : TextColor.color(0xFF4444))
                    .decoration(TextDecoration.ITALIC, false)),
            Component.text(""),
            can ? Component.text("  ► Нажмите, чтобы купить").color(TextColor.color(0x55FF55)).decoration(TextDecoration.ITALIC, false)
                : Component.text("  ✗ Недостаточно Арисов").color(TextColor.color(0xFF4444)).decoration(TextDecoration.ITALIC, false),
            Component.text("")
        ));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack arisShopItem(long bal, long price) {
        ItemStack item = ArisItemManager.createArisBlock();
        ItemMeta meta = item.getItemMeta();
        boolean can = bal >= price;
        meta.displayName(
            Component.text("✦ ").color(TextColor.color(0xFF4400))
            .append(Component.text("А").color(TextColor.color(0xFF5500)))
            .append(Component.text("р").color(TextColor.color(0xFF6600)))
            .append(Component.text("и").color(TextColor.color(0xFF7700)))
            .append(Component.text("с").color(TextColor.color(0xFF8800)))
            .append(Component.text(" ✦").color(TextColor.color(0xFF9900)))
            .decoration(TextDecoration.ITALIC, false).decoration(TextDecoration.BOLD, true)
        );
        meta.lore(List.of(
            Component.text(""),
            Component.text("  Легендарный артефакт").color(TextColor.color(0xFFAA33)).decoration(TextDecoration.ITALIC, false),
            Component.text("  из запретных измерений.").color(TextColor.color(0xFF8C00)).decoration(TextDecoration.ITALIC, false),
            Component.text(""),
            Component.text("  Размер: ").color(TextColor.color(0x888888)).decoration(TextDecoration.ITALIC, false)
                .append(Component.text("52×52×52").color(TextColor.color(0xFFCC55)).decoration(TextDecoration.ITALIC, false)),
            Component.text(""),
            Component.text("  Цена: ").color(TextColor.color(0x888888)).decoration(TextDecoration.ITALIC, false)
                .append(Component.text(fmt(price) + " ✦").color(TextColor.color(0xFF8000))
                    .decoration(TextDecoration.BOLD, true).decoration(TextDecoration.ITALIC, false)),
            Component.text("  Баланс: ").color(TextColor.color(0x888888)).decoration(TextDecoration.ITALIC, false)
                .append(Component.text(fmt(bal) + " ✦")
                    .color(can ? TextColor.color(0x55FF55) : TextColor.color(0xFF4444))
                    .decoration(TextDecoration.ITALIC, false)),
            Component.text(""),
            can ? Component.text("  ► Нажмите, чтобы купить").color(TextColor.color(0x55FF55)).decoration(TextDecoration.ITALIC, false)
                : Component.text("  ✗ Недостаточно Арисов").color(TextColor.color(0xFF4444)).decoration(TextDecoration.ITALIC, false),
            Component.text("")
        ));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack tntShopItem(TntType type, long bal) {
        ItemStack item = TntItemManager.createTnt(type);
        ItemMeta meta = item.getItemMeta();
        boolean can = bal >= type.getPrice();
        List<Component> lore = new ArrayList<>(meta.lore() != null ? meta.lore() : List.of());
        lore.add(Component.text("  Баланс: ").color(TextColor.color(0x888888)).decoration(TextDecoration.ITALIC, false)
            .append(Component.text(fmt(bal) + " ✦")
                .color(can ? TextColor.color(0x55FF55) : TextColor.color(0xFF4444))
                .decoration(TextDecoration.ITALIC, false)));
        lore.add(Component.text(""));
        lore.add(can
            ? Component.text("  ► Нажмите, чтобы купить").color(TextColor.color(0x55FF55)).decoration(TextDecoration.ITALIC, false)
            : Component.text("  ✗ Недостаточно Арисов").color(TextColor.color(0xFF4444)).decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text(""));
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack minecartShopItem(MinecartType type, long bal) {
        ItemStack item = MinecartItemManager.createMinecart(type);
        ItemMeta meta = item.getItemMeta();
        boolean can = bal >= type.getPrice();
        List<Component> lore = new ArrayList<>(meta.lore() != null ? meta.lore() : List.of());
        lore.add(Component.text("  Баланс: ").color(TextColor.color(0x888888)).decoration(TextDecoration.ITALIC, false)
            .append(Component.text(fmt(bal) + " ✦")
                .color(can ? TextColor.color(0x55FF55) : TextColor.color(0xFF4444))
                .decoration(TextDecoration.ITALIC, false)));
        lore.add(Component.text(""));
        lore.add(can
            ? Component.text("  ► Нажмите, чтобы купить").color(TextColor.color(0x55FF55)).decoration(TextDecoration.ITALIC, false)
            : Component.text("  ✗ Недостаточно Арисов").color(TextColor.color(0xFF4444)).decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text(""));
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack rgbItem(Material mat, String name, String desc) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name).decoration(TextDecoration.ITALIC, false).decoration(TextDecoration.BOLD, true));
        meta.lore(List.of(
            Component.text(""),
            Component.text("  " + desc).color(TextColor.color(0xAAAAAA)).decoration(TextDecoration.ITALIC, false),
            Component.text(""),
            Component.text("  (Декоративный ингредиент)").color(TextColor.color(0x555555)).decoration(TextDecoration.ITALIC, true)
        ));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack tabButton(Material mat, String name, String desc) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name).decoration(TextDecoration.ITALIC, false).decoration(TextDecoration.BOLD, true));
        meta.lore(List.of(
            Component.text(""),
            Component.text("  " + desc).color(TextColor.color(0x55FFFF)).decoration(TextDecoration.ITALIC, false),
            Component.text("")
        ));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack balanceDisplay(long bal) {
        ItemStack item = new ItemStack(Material.GOLD_NUGGET);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("✦ Ваш баланс ✦").color(TextColor.color(0xFFDD00))
            .decoration(TextDecoration.ITALIC, false).decoration(TextDecoration.BOLD, true));
        meta.lore(List.of(
            Component.text(""),
            Component.text("  ").decoration(TextDecoration.ITALIC, false)
                .append(Component.text(fmt(bal) + " Арисов ✦")
                    .color(TextColor.color(0xFF8000))
                    .decoration(TextDecoration.BOLD, true).decoration(TextDecoration.ITALIC, false)),
            Component.text("")
        ));
        item.setItemMeta(meta);
        return item;
    }

    private void fillBorder(Inventory inv) {
        ItemStack g = borderGlass();
        for (int i = 0; i < 9; i++)  inv.setItem(i, g);
        for (int i = 45; i < 54; i++) inv.setItem(i, g);
        for (int i = 9; i < 45; i += 9)  inv.setItem(i, g);
        for (int i = 17; i < 54; i += 9) inv.setItem(i, g);
    }

    private ItemStack borderGlass() {
        ItemStack g = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta m = g.getItemMeta();
        m.displayName(Component.text(" ").decoration(TextDecoration.ITALIC, false));
        g.setItemMeta(m);
        return g;
    }

    private String fmt(long n) { return String.format("%,d", n).replace(',', ' '); }
}
